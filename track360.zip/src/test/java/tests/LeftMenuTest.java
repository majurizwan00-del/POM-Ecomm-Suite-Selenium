package tests;

public class LeftMenuTest {
}
